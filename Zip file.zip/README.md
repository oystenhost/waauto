# Waauto
### Waauto - Whmcs Whatsapp Module Getway

[You can Buy 299/- INR Monthly package And user this Module to Send Whatsapp Notification to your whmcs users.](https://waauto.in/price "You can Buy 299/- INR Monthly package And user this Module to Send Whatsapp Notification to your whmcs users.")

##  Feature

1. WHMCS Login Alert
2. WHMCS Password Changed
3. WHMCS Invoice Created
4. WHMCS Invoice Payment Reminder
5. WHMCS Payment Confirmation	
6. WHMCS Invoice Cancellation
7. WHMCS Product/service Service Suspension	
8. WHMCS Service Reactivation	
9. WHMCS Ticket Opened	
10. Ticket Replied	
11. Ticket Closed	
12. WHMCS New Client Registration	
13. Product Termination	
14. New Product Activation	
15. Hosting Account Information	

##  Change Log

   Version 1.0
1. WHMCS Login Alert
2. WHMCS Password Changed
3. WHMCS Invoice Created
4. WHMCS Invoice Payment Reminder
5. WHMCS Payment Confirmation	
6. WHMCS Invoice Cancellation
7. WHMCS Product/service Service Suspension	
8. WHMCS Service Reactivation	
9. WHMCS Ticket Opened	
10. Ticket Replied	
11. Ticket Closed	
12. WHMCS New Client Registration	
13. Product Termination	
14. New Product Activation	
15. Hosting Account Information
